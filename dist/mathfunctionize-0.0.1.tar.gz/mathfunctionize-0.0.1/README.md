# mathfunctionize
 A python library for math functions in advanced fields of math.
